DONE | 2D L-Systemen                 
DONE | 3D Lijntekeningen           
DONE | 3D Lichamen                  
DONE | Z-Buffering met lijnen       
DONE | Z-Buffering met driehoeken  
PARITAL | 3D Fractalen
* DONE | Platonische lichamen  
* DONE | BuckyBall